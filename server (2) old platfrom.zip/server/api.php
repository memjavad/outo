<?php
session_start();
spl_autoload_register(function ($class) {
    if (strpos($class, 'App\\') === 0) {
        $file = __DIR__ . '/src/' . str_replace('\\', '/', substr($class, 4)) . '.php';
        if (file_exists($file)) {
            require_once $file;
        }
    }
});

use App\Core\Database;
use App\Core\Auth;
use App\Core\ErrorHandler;
use App\Repositories\SecurityRepository;
use App\Services\SecurityService;

// Initialize Global Error Handler
ErrorHandler::register();

if (isset($_SERVER['HTTP_ORIGIN'])) {
    header("Access-Control-Allow-Origin: {$_SERVER['HTTP_ORIGIN']}");
} else {
    header("Access-Control-Allow-Origin: *");
}
header("Access-Control-Allow-Methods: GET, POST, DELETE, OPTIONS, PUT");
header("Access-Control-Allow-Headers: Content-Type, X-API-Key, Authorization, X-Requested-With");
header("Access-Control-Allow-Credentials: true");
header("Content-Type: application/json");

// Connect to DB via Singleton
$pdo = Database::getInstance();

$method = $_SERVER['REQUEST_METHOD'];
$clientIp = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';

// Handle OPTIONS for CORS
if ($method === 'OPTIONS') {
    exit;
}

// ── Core Security Evaluations ────────────────────────
$securityService = new SecurityService(new SecurityRepository($pdo));
$securityService->enforceRateLimits($clientIp, 'general', 200);
$securityService->enforceIpWhitelist($clientIp);

// Read request body
$requestBody = file_get_contents("php://input");
$data = json_decode($requestBody, true) ?? [];

// Extract headers
$headers = getallheaders();
$authHeader = $headers['Authorization'] ?? '';
$apiKey = $_SERVER['HTTP_X_API_KEY'] ?? $_GET['api_key'] ?? null;

// Resolve Identities
$authData = $securityService->resolveAuthentication($authHeader, $apiKey, $_SESSION);
$isAdmin = $authData['is_admin'];
$adminId = $authData['admin_id'];
$studentId = $authData['student_id'];

// Dispatch to Router
$router = new App\Core\Router($method, $_SERVER['REQUEST_URI']);
$routerResponse = $router->dispatch($isAdmin, $adminId, $studentId);

if ($routerResponse !== null) {
    exit;
}

// Fallback
http_response_code(404);
echo json_encode(["status" => "error", "error" => "Endpoint not found"]);
?>
