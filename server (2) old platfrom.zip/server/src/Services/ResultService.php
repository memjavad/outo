<?php
namespace App\Services;

use App\Repositories\ResultRepository;

class ResultService {
    private ResultRepository $resultRepo;

    public function __construct(ResultRepository $resultRepo) {
        $this->resultRepo = $resultRepo;
    }

    public function saveResult(array $data): array {
        $studentName = $data['studentName'];
        
        $resultData = [
            'student_name' => $studentName,
            'student_id' => $data['studentId'] ?? null,
            'exam_id' => $data['examId'] ?? null,
            'score_percentage' => $data['scorePercentage'] ?? 0,
            'grade' => $data['grade'] ?? 'F',
            'total_questions' => $data['totalQuestions'] ?? 0,
            'correct_answers' => $data['correctAnswers'] ?? 0,
            'time_taken_seconds' => $data['timeTakenSeconds'] ?? 0,
            'gps_location' => $data['gpsLocation'] ?? null,
            'cheat_flag' => $data['cheatFlag'] ?? null,
            'answers_json' => isset($data['answersJson']) ? json_encode($data['answersJson']) : null
        ];

        $resultId = $this->resultRepo->createResult($resultData);
        $this->resultRepo->markSessionCompleted($studentName);
        
        // Calculate Reward Points securely
        $correctAns = (int)($data['correctAnswers'] ?? 0);
        $totalQ = (int)($data['totalQuestions'] ?? 0);
        $timeTaken = (int)($data['timeTakenSeconds'] ?? 99999);
        $scoreStr = rtrim((string)($data['scorePercentage'] ?? '0'), '% ');
        $scorePct = (float)$scoreStr;
        
        $earnedPoints = $correctAns * 10;
        if ($scorePct >= 99.9) $earnedPoints += 50; // Flawless DB mapping
        if ($timeTaken > 0 && $timeTaken <= ($totalQ * 30)) $earnedPoints += 25; // Speed bonus mapping
        $earnedPoints = max(10, $earnedPoints); // Min participation award
        
        $studentIdTarget = $data['studentId'] ?? null;
        if ($studentIdTarget) {
            $this->resultRepo->awardPoints((int)$studentIdTarget, $earnedPoints);
            $this->resultRepo->insertLedger($studentName, $earnedPoints, "Completed Exam ID: " . ($data['examId'] ?? 'Unknown'));
        }

        $this->triggerWebhook('result_submitted', $data);
        
        return [
            "status" => "success", 
            "id" => $resultId, 
            "points_earned" => $earnedPoints
        ];
    }

    public function getStudentResults(int $studentId): array {
        return $this->resultRepo->getStudentResults($studentId);
    }

    public function getLeaderboard(int $examId): array {
        $leaderboard = $this->resultRepo->getLeaderboard($examId);
        return [
            "status" => "success",
            "leaderboard" => $leaderboard
        ];
    }

    public function clearResults(): array {
        $this->resultRepo->clearResults();
        return ["status" => "success"];
    }

    private function triggerWebhook(string $eventName, array $payload) {
        if ($this->resultRepo->isWebhookEnabled()) {
            $webhooks = $this->resultRepo->getActiveWebhooks($eventName);
            foreach ($webhooks as $row) {
                $ch = curl_init($row['url']);
                curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
                curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                curl_setopt($ch, CURLOPT_TIMEOUT, 2);
                curl_exec($ch);
                curl_close($ch);
            }
        }
    }
}
