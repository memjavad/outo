<?php
namespace App\Core;

class Config {
    public static function get($key, $default = null) {
        $config = [
            'db_host' => 'localhost',
            'db_name' => 's_ss',
            'db_user' => 's_ss',
            'db_pass' => 'LI!9tWdp^2qFCDce',
            'jwt_secret' => 'sdgfdbvbnghjghjfghdfgdFGDFGDFHGH#$34DF@32#$#%$%^%',
            'token_expiry' => 86400 // 24 hours
        ];
        
        return $config[$key] ?? $default;
    }
}
