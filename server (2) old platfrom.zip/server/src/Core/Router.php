<?php
namespace App\Core;

class Router {
    private $controller;
    private $action;
    private $params;

    public function __construct($method, $uri) {
        global $data;
        // Simple routing logic: api.php?action=xxx
        $this->action = $_GET['action'] ?? ($_POST['action'] ?? ($data['action'] ?? 'index'));
        $this->params = array_merge($_GET, $_POST);
        
        if (isset($data) && is_array($data)) {
            $this->params = array_merge($this->params, $data);
        }
    }

    public function dispatch($isAdmin = false, $adminId = null, $studentId = null) {
        // Map actions to routes and apply middleware rules
        $routes = [
            'questions' => ['controller' => 'ExamController', 'method' => 'getQuestions', 'middleware' => 'none'],
            'exams' => ['controller' => 'ExamController', 'method' => 'getExams', 'middleware' => 'none'],
            'add_exam' => ['controller' => 'ExamController', 'method' => 'addExam', 'middleware' => 'admin'],
            'update_exam' => ['controller' => 'ExamController', 'method' => 'updateExam', 'middleware' => 'admin'],
            'add_question' => ['controller' => 'ExamController', 'method' => 'addQuestion', 'middleware' => 'admin'],
            'update_question' => ['controller' => 'ExamController', 'method' => 'updateQuestion', 'middleware' => 'admin'],
            'get_question_details' => ['controller' => 'ExamController', 'method' => 'getQuestionDetails', 'middleware' => 'admin'],
            'analytics_data' => ['controller' => 'AjaxController', 'method' => 'getAnalytics', 'middleware' => 'admin'],
            'delete_item' => ['controller' => 'AjaxController', 'method' => 'deleteItem', 'middleware' => 'admin'],
            'add_student' => ['controller' => 'StudentController', 'method' => 'addStudent', 'middleware' => 'admin'],
            'pending_students' => ['controller' => 'StudentController', 'method' => 'getPendingStudents', 'middleware' => 'admin'],
            'approve_student' => ['controller' => 'StudentController', 'method' => 'approveStudent', 'middleware' => 'admin'],
            'reject_student' => ['controller' => 'StudentController', 'method' => 'rejectStudent', 'middleware' => 'admin'],
            'settings' => ['controller' => 'SettingsController', 'method' => 'getSettings', 'middleware' => 'none'],
            'update_settings' => ['controller' => 'SettingsController', 'method' => 'updateSettings', 'middleware' => 'admin'],
            'fix_database_schema' => ['controller' => 'SettingsController', 'method' => 'fixDatabaseSchema', 'middleware' => 'admin'],
            'update_system' => ['controller' => 'UpdateController', 'method' => 'upload', 'middleware' => 'admin'],
            'live_sessions' => ['controller' => 'SessionController', 'method' => 'listActive', 'middleware' => 'admin'],
            'clear_results' => ['controller' => 'ResultController', 'method' => 'clearResults', 'middleware' => 'admin'],

            // Public / Student Actions
            'login' => ['controller' => 'AuthController', 'method' => 'apiLogin', 'middleware' => 'none'],
            'check_tg_login' => ['controller' => 'AuthController', 'method' => 'checkTelegramLogin', 'middleware' => 'none'],
            'student_register' => ['controller' => 'StudentController', 'method' => 'registerStudent', 'middleware' => 'none'],
            'student_login' => ['controller' => 'StudentController', 'method' => 'loginStudent', 'middleware' => 'none'],
            'check_access_code' => ['controller' => 'StudentController', 'method' => 'checkAccessCode', 'middleware' => 'none'],

            // Student Authenticated Actions
            'student_profile' => ['controller' => 'StudentController', 'method' => 'getProfile', 'middleware' => 'student'],
            'update_student_profile' => ['controller' => 'StudentController', 'method' => 'updateProfile', 'middleware' => 'student'],
            'save_result' => ['controller' => 'ResultController', 'method' => 'saveResult', 'middleware' => 'student'],
            'student_results' => ['controller' => 'ResultController', 'method' => 'getStudentResults', 'middleware' => 'student'],
            'get_leaderboard' => ['controller' => 'ResultController', 'method' => 'getLeaderboard', 'middleware' => 'student'],
            'start_session' => ['controller' => 'SessionController', 'method' => 'startSession', 'middleware' => 'student'],
            'heartbeat_session' => ['controller' => 'SessionController', 'method' => 'heartbeat', 'middleware' => 'student'],
        ];

        if (!isset($routes[$this->action])) {
            return null;
        }

        $route = $routes[$this->action];
        $middleware = new Middleware();
        
        // Handle Middleware Authorization
        if (!$middleware->handle($route['middleware'], $isAdmin, $studentId)) {
            http_response_code(401);
            echo json_encode(['error' => 'Unauthorized action.']);
            exit;
        }

        $controllerName = $route['controller'];
        $method = $route['method'];
        $controllerClass = "App\\Controllers\\" . $controllerName;
        
        if (class_exists($controllerClass)) {
            $controller = new $controllerClass();
            if (method_exists($controller, $method)) {
                $actorId = null;
                if ($route['middleware'] === 'none') {
                    $actorId = $adminId ?? $studentId;
                } elseif ($route['middleware'] === 'student') {
                    $actorId = $studentId;
                } else {
                    $actorId = $adminId;
                }
                
                return $controller->$method($this->params, $_FILES, $actorId);
            }
        }
        
        return null;
    }
}
