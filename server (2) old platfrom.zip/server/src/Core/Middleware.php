<?php
namespace App\Core;

class Middleware {
    /**
     * Checks if the required authorization level is met.
     */
    public function handle(string $requiredLevel, bool $isAdmin, ?int $studentId): bool {
        if ($requiredLevel === 'admin') {
            return $isAdmin;
        }
        if ($requiredLevel === 'student') {
            return $studentId !== null;
        }
        if ($requiredLevel === 'none') {
            return true;
        }
        return false;
    }
}
