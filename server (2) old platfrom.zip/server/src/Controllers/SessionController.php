<?php
namespace App\Controllers;

use App\Core\Database;
use App\Core\Validator;
use App\Repositories\SessionRepository;
use App\Services\SessionService;

class SessionController extends BaseController {
    public function startSession($data, $files = null, $adminId = null) {
        $validation = Validator::validate($data, ['studentName' => 'required|string']);
        if (!$validation['passes']) return $this->json(["error" => "studentName is required"], 400);

        $db = Database::getInstance();
        $sessionService = new SessionService(new SessionRepository($db));
        
        $ip = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
        try {
            return $this->json($sessionService->startSession($data, $ip));
        } catch (\Exception $e) {
            return $this->json(["error" => $e->getMessage()], 500);
        }
    }

    public function heartbeat($data, $files = null, $adminId = null) {
        $validation = Validator::validate($data, ['studentName' => 'required|string']);
        if (!$validation['passes']) return $this->json(["error" => "studentName is required"], 400);

        $db = Database::getInstance();
        $sessionService = new SessionService(new SessionRepository($db));

        try {
            return $this->json($sessionService->processHeartbeat($data));
        } catch (\Exception $e) {
            return $this->json(["error" => $e->getMessage()], 500);
        }
    }

    public function listActive($data, $files = null, $adminId = null) {
        $db = Database::getInstance();
        $sessionService = new SessionService(new SessionRepository($db));
        return $this->json($sessionService->listActiveSessions());
    }
}
