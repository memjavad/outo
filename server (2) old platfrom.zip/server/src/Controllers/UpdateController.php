<?php
namespace App\Controllers;

use App\Core\Database;
use App\Core\Config;
use App\Repositories\SettingsRepository;
use App\Services\UpdateService;

class UpdateController extends BaseController {
    public function upload($data, $files = null, $adminId = null) {
        if (!$adminId) {
            return $this->json(["error" => "Unauthorized"], 401);
        }

        if (!class_exists('ZipArchive')) {
            return $this->json(["error" => "ZipArchive extension is not enabled on this server."], 500);
        }

        if (!$files || !isset($files['update_zip'])) {
            return $this->json(["error" => "No ZIP file uploaded"], 400);
        }

        if ($files['update_zip']['error'] !== UPLOAD_ERR_OK) {
            return $this->json(["error" => "Upload failed. Error code: " . $files['update_zip']['error']], 400);
        }

        $db = Database::getInstance();
        $rootPath = realpath(__DIR__ . '/../../');
        $updateService = new UpdateService(new SettingsRepository($db), $rootPath);

        try {
            return $this->json($updateService->processUpdate($files['update_zip'], $data['new_version'] ?? null));
        } catch (\Exception $e) {
            $code = $e->getCode() ?: 500;
            if ($code === 0) $code = 400;
            return $this->json(["error" => $e->getMessage()], $code);
        }
    }
}
