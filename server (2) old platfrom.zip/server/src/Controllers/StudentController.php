<?php
namespace App\Controllers;

use App\Core\Database;
use App\Repositories\StudentRepository;
use App\Services\StudentService;

class StudentController extends BaseController {
    
    public function getStudents($data = null, $files = null, $adminId = null) {
        if (!$adminId) return $this->json(["error" => "Unauthorized"], 401);
        $db = Database::getInstance();
        $studentRepo = new StudentRepository($db);
        return $this->json($studentRepo->getAll());
    }

    public function addStudent($data, $files = null, $adminId = null) {
        $validation = \App\Core\Validator::validate($data, [
            'name' => 'required|string',
            'phone' => 'required|string',
            'password' => 'required|string'
        ]);

        if (!$validation['passes']) {
            return $this->json(["error" => "Validation failed", "details" => $validation['errors']], 400);
        }
        $val = $validation['validated'];

        $db = Database::getInstance();
        $studentService = new StudentService(new StudentRepository($db));
        
        try {
            return $this->json($studentService->addStudent($val));
        } catch (\Exception $e) {
            $code = $e->getCode() ?: 500;
            if ($code === 0) $code = 400; // default for known domain errors
            return $this->json(["error" => $e->getMessage()], $code);
        }
    }

    public function bulkImport($data, $files = null, $adminId = null) {
        if (!isset($data['students']) || !is_array($data['students'])) {
            return $this->json(["error" => "Missing students array"], 400);
        }

        $db = Database::getInstance();
        $studentService = new StudentService(new StudentRepository($db));
        return $this->json($studentService->bulkImport($data['students']));
    }

    public function registerStudent($data, $files = null, $adminId = null) {
        $validation = \App\Core\Validator::validate($data, [
            'name' => 'required|string',
            'phone' => 'required|string',
            'password' => 'required|string'
        ]);

        if (!$validation['passes']) {
            return $this->json(["error" => "Validation failed", "details" => $validation['errors']], 400);
        }
        $val = $validation['validated'];

        $db = Database::getInstance();
        $studentService = new StudentService(new StudentRepository($db));
        
        try {
            return $this->json($studentService->registerStudent($val));
        } catch (\Exception $e) {
            return $this->json(["error" => "Registration failed: " . $e->getMessage()], 500);
        }
    }

    public function loginStudent($data, $files = null, $adminId = null) {
        $validation = \App\Core\Validator::validate($data, [
            'phone' => 'required|string',
            'password' => 'required|string'
        ]);

        if (!$validation['passes']) {
            return $this->json(["error" => "Validation failed", "details" => $validation['errors']], 400);
        }
        $val = $validation['validated'];

        $db = Database::getInstance();
        $studentService = new StudentService(new StudentRepository($db));
        
        try {
            return $this->json($studentService->loginStudent($val));
        } catch (\Exception $e) {
            return $this->json(["error" => "Login Exception: " . $e->getMessage()], 401);
        }
    }

    public function getProfile($data, $files = null, $studentId = null) {
        if (!$studentId) return $this->json(["error" => "Unauthorized"], 401);
        
        $db = Database::getInstance();
        $studentRepo = new StudentRepository($db);
        $student = $studentRepo->findById($studentId);

        if ($student) {
            unset($student['password_hash']);
            return $this->json($student);
        }
        return $this->json(["error" => "Student not found"], 404);
    }

    public function updateProfile($data, $files = null, $studentId = null) {
        if (!$studentId) return $this->json(["error" => "Unauthorized"], 401);

        $db = Database::getInstance();
        $studentRepo = new StudentRepository($db);
        
        $name = $data['name'] ?? null;
        $bio = $data['bio'] ?? null;
        
        $updateData = [];

        if ($name) $updateData['name'] = $name;
        if ($bio !== null) $updateData['bio'] = $bio;

        if (isset($files['profile_image']) && $files['profile_image']['error'] === UPLOAD_ERR_OK) {
            $examController = new ExamController();
            $upload = $examController->uploadImage($files['profile_image']);
            if (isset($upload['url'])) {
                $updateData['profile_image'] = $upload['url'];
            }
        }

        if (empty($updateData)) return $this->json(["status" => "success", "message" => "No changes made"]);

        try {
            $studentRepo->update($studentId, $updateData);
            return $this->json(["status" => "success", "message" => "Profile updated"]);
        } catch (\Exception $e) {
            return $this->json(["error" => "Profile update failed"], 500);
        }
    }

    public function getPendingStudents($data = null, $files = null, $adminId = null) {
        if (!$adminId) return $this->json(["error" => "Unauthorized"], 401);
        $db = Database::getInstance();
        $studentRepo = new StudentRepository($db);
        return $this->json($studentRepo->getPending());
    }

    public function approveStudent($data, $files = null, $adminId = null) {
        if (!$adminId) return $this->json(["error" => "Unauthorized"], 401);
        $validation = \App\Core\Validator::validate($data, ['id' => 'required|numeric']);
        if (!$validation['passes']) return $this->json(["error" => "Student ID required"], 400);

        $id = $validation['validated']['id'];

        $db = Database::getInstance();
        $studentRepo = new StudentRepository($db);
        try {
            $studentRepo->approve($id);
            return $this->json(["status" => "success", "message" => "Student approved"]);
        } catch (\Exception $e) {
            return $this->json(["error" => "Failed to approve student"], 500);
        }
    }

    public function rejectStudent($data, $files = null, $adminId = null) {
        if (!$adminId) return $this->json(["error" => "Unauthorized"], 401);
        $validation = \App\Core\Validator::validate($data, ['id' => 'required|numeric']);
        if (!$validation['passes']) return $this->json(["error" => "Student ID required"], 400);

        $id = $validation['validated']['id'];

        $db = Database::getInstance();
        $studentRepo = new StudentRepository($db);
        try {
            $studentRepo->reject($id);
            return $this->json(["status" => "success", "message" => "Student rejected"]);
        } catch (\Exception $e) {
            return $this->json(["error" => "Failed to reject student"], 500);
        }
    }
}
