<?php
namespace App\Controllers;

use App\Core\Database;
use App\Core\Validator;
use App\Repositories\AdminRepository;
use App\Services\AuthService;

class AuthController extends BaseController {
    
    /**
     * API Login - Returns JSON with token
     */
    public function apiLogin($data, $files = null, $adminId = null) {
        $validation = Validator::validate($data, [
            'username' => 'required|string',
            'password' => 'required|string'
        ]);

        if (!$validation['passes']) return $this->json(["error" => "Missing username or password"], 400);

        $db = Database::getInstance();
        $authService = new AuthService(new AdminRepository($db));
        
        $result = $authService->apiLogin($validation['validated']['username'], $validation['validated']['password']);
        
        if (isset($result['error'])) {
            return $this->json($result, 401);
        }

        return $this->json($result);
    }

    /**
     * Web Login - Sets session and redirects
     */
    public function webLogin($data) {
        $username = $data['username'] ?? '';
        $password = $data['password'] ?? '';
        
        if (empty($username) || empty($password)) {
            $_SESSION['login_error'] = "Missing username or password";
            return false;
        }

        $db = Database::getInstance();
        $authService = new AuthService(new AdminRepository($db));
        
        $result = $authService->authenticate($username, $password);
        if (isset($result['error'])) {
            $_SESSION['login_error'] = $result['error'];
            return false;
        }

        $_SESSION['admin_logged_in'] = true;
        $_SESSION['admin_id'] = $result['admin']['id'];
        $_SESSION['admin_user'] = $result['admin']['username'];

        // Force password change if using 'password'
        if ($result['is_default']) {
            $_SESSION['force_password_change'] = true;
        }

        return true;
    }

    /**
     * First-run Registration
     */
    public function registerFirstAdmin($data) {
        $username = $data['username'] ?? '';
        $password = $data['password'] ?? '';

        if (empty($username) || strlen($password) < 6) {
            $_SESSION['login_error'] = "Username required and Password must be 6+ chars.";
            return false;
        }

        $db = Database::getInstance();
        $authService = new AuthService(new AdminRepository($db));

        try {
            $authService->registerFirstAdmin($username, $password);
            return $this->webLogin($data);
        } catch (\Exception $e) {
            if ($e->getMessage() === "Admin already exists.") {
                die("Admin already exists.");
            }
            $_SESSION['login_error'] = $e->getMessage();
            return false;
        }
    }

    public function checkTelegramLogin($data, $files = null, $adminId = null) {
        $validation = Validator::validate($data, ['session_id' => 'required|string']);
        if (!$validation['passes']) return $this->json(["error" => "Missing session_id"], 400);

        $db = Database::getInstance();
        $authService = new AuthService(new AdminRepository($db));

        try {
            $result = $authService->checkTelegramLogin($validation['validated']['session_id']);
            return $this->json($result);
        } catch (\Exception $e) {
            return $this->json(["error" => $e->getMessage()], 404);
        }
    }
}
