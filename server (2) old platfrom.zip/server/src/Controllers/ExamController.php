<?php
namespace App\Controllers;

use App\Core\Database;
use App\Repositories\ExamRepository;
use App\Repositories\QuestionRepository;
use App\Services\ExamService;

class ExamController extends BaseController {
    
    public function getQuestions($data, $files = null, $adminId = null) {
        $db = Database::getInstance();
        $stmtSettings = $db->query("SELECT setting_value FROM settings WHERE setting_key = 'randomize_questions'");
        $randSetting = $stmtSettings->fetchColumn();
        $isRand = ($randSetting === false || $randSetting == '1');
        
        $examId = $data['exam_id'] ?? null;
        
        $questionRepo = new QuestionRepository($db);
        
        if ($examId) {
            $questions = $questionRepo->getByExamId((int)$examId, $isRand);
        } else {
            $questions = $questionRepo->getAll($isRand);
        }

        $result = [];
        foreach ($questions as $q) {
            $optionsList = array_map(fn($opt) => $opt['option_text'], $q['options']);

            $result[] = [
                'id' => (string)$q['id'],
                'categoryId' => $q['category_id'] ? (string)$q['category_id'] : null,
                'examId' => $q['exam_id'] ? (string)$q['exam_id'] : null,
                'question' => $q['question_text'],
                'richText' => $q['rich_text'],
                'imageUrl' => $q['image_url'],
                'questionType' => $q['question_type'] ?? 'single',
                'options' => $optionsList,
                'correctAnswerIndex' => (int)$q['correct_answer_index'],
                'points' => (int)($q['points'] ?? 1)
            ];
        }
        return $this->json($result);
    }

    public function getExams($data, $files = null, $adminId = null) {
        $db = Database::getInstance();
        $examRepo = new ExamRepository($db);

        if ($adminId) {
            $stmtRole = $db->prepare("SELECT role FROM admins WHERE id = ?");
            $stmtRole->execute([$adminId]);
            $role = $stmtRole->fetchColumn();
            
            if ($role === 'admin') {
                return $this->json($examRepo->getAllForAdmin());
            } else {
                return $this->json($examRepo->getAllForTeacher($adminId));
            }
        } else {
            return $this->json($examRepo->getAllActive());
        }
    }

    public function addQuestion($data, $files = null, $adminId = null) {
        $db = Database::getInstance();
        $questionRepo = new QuestionRepository($db);

        $validation = \App\Core\Validator::validate($data, [
            'question_text' => 'required|string'
        ]);
        if (!$validation['passes']) return $this->json(["error" => "Validation failed", "details" => $validation['errors']], 400);
        $questionText = $validation['validated']['question_text'];

        $categoryId = !empty($data['category_id']) ? $data['category_id'] : null;
        $examId = !empty($data['exam_id']) ? $data['exam_id'] : null;
        $questionText = $data['question_text'] ?? '';
        $richText = !empty($data['rich_text']) ? $data['rich_text'] : null;
        $correctIndex = $data['correct_index'] ?? 0;
        $domain = $data['domain'] ?? 'standard';
        
        $options = [];
        for ($i = 0; $i < 4; $i++) {
            if (isset($data["option_$i"])) $options[] = $data["option_$i"];
        }

        try {
            $db->beginTransaction();
            $imageUrl = null;
            if (isset($files['question_image']) && $files['question_image']['error'] === UPLOAD_ERR_OK) {
                $upload = $this->uploadImage($files['question_image']);
                $imageUrl = $upload['url'] ?? null;
            }

            $questionData = [
                'category_id' => $categoryId,
                'exam_id' => $examId,
                'question_text' => $questionText,
                'rich_text' => $richText,
                'image_url' => $imageUrl,
                'correct_answer_index' => $correctIndex,
                'domain' => $domain
            ];

            $questionId = $questionRepo->createQuestion($questionData);

            foreach ($options as $index => $text) {
                $questionRepo->createOption($questionId, $text, $index);
            }

            $db->commit();
            return $this->json(["status" => "success", "id" => $questionId, "question" => $questionText, "imageUrl" => $imageUrl]);
        } catch (\Exception $e) {
            if ($db->inTransaction()) $db->rollBack();
            return $this->json(["error" => $e->getMessage()], 500);
        }
    }

    public function addExam($data, $files = null, $adminId = null) {
        $db = Database::getInstance();
        $examRepo = new ExamRepository($db);

        $validation = \App\Core\Validator::validate($data, [
            'title' => 'required|string',
            'description' => 'string'
        ]);
        if (!$validation['passes']) {
            return $this->json(["error" => "Validation failed", "details" => $validation['errors']], 400);
        }
        
        $examService = new ExamService($examRepo);

        try {
            return $this->json($examService->addExam($validation['validated'], $adminId));
        } catch (\Exception $e) {
            return $this->json(["error" => $e->getMessage()], 500);
        }
    }

    public function updateExam($data, $files = null, $adminId = null) {
        $db = Database::getInstance();
        $examRepo = new ExamRepository($db);

        $validation = \App\Core\Validator::validate($data, [
            'id' => 'required|numeric',
            'title' => 'required|string',
            'description' => 'string'
        ]);
        if (!$validation['passes']) {
            return $this->json(["error" => "Validation failed", "details" => $validation['errors']], 400);
        }
        $id = $validation['validated']['id'];

        $examService = new ExamService($examRepo);

        try {
            return $this->json($examService->updateExam((int)$id, $data));
        } catch (\Exception $e) {
            return $this->json(["error" => $e->getMessage()], 500);
        }
    }

    public function getQuestionDetails($data, $files = null, $adminId = null) {
        $db = Database::getInstance();
        $validation = \App\Core\Validator::validate($data, ['id' => 'required|numeric']);
        if (!$validation['passes']) return $this->json(["error" => "ID is required"], 400);
        $id = $validation['validated']['id'];

        $stmt = $db->prepare("SELECT * FROM questions WHERE id = ?");
        $stmt->execute([$id]);
        $q = $stmt->fetch(\PDO::FETCH_ASSOC);
        if (!$q) return $this->json(["error" => "Question not found"], 404);

        $questionRepo = new QuestionRepository($db);
        $q['options'] = $questionRepo->getOptions($id);

        return $this->json($q);
    }

    public function updateQuestion($data, $files = null, $adminId = null) {
        $db = Database::getInstance();
        $questionRepo = new QuestionRepository($db);

        $validation = \App\Core\Validator::validate($data, [
            'id' => 'required|numeric',
            'question_text' => 'required|string'
        ]);
        if (!$validation['passes']) return $this->json(["error" => "Validation failed", "details" => $validation['errors']], 400);
        
        $id = $validation['validated']['id'];
        $questionText = $validation['validated']['question_text'];

        $options = [];
        for ($i = 0; $i < 4; $i++) {
            if (isset($data["option_$i"])) $options[] = $data["option_$i"];
        }

        try {
            $db->beginTransaction();
            
            // Handle image update
            $imageUrl = $data['existing_image'] ?? null;
            if (isset($files['question_image']) && $files['question_image']['error'] === UPLOAD_ERR_OK) {
                $upload = $this->uploadImage($files['question_image']);
                $imageUrl = $upload['url'] ?? null;
            }

            $questionData = [
                'category_id' => !empty($data['category_id']) ? $data['category_id'] : null,
                'exam_id' => !empty($data['exam_id']) ? $data['exam_id'] : null,
                'question_text' => $questionText,
                'rich_text' => !empty($data['rich_text']) ? $data['rich_text'] : null,
                'image_url' => $imageUrl,
                'correct_answer_index' => $data['correct_index'] ?? 0,
                'domain' => $data['domain'] ?? 'standard'
            ];

            $questionRepo->updateQuestion((int)$id, $questionData);

            $questionRepo->deleteOptions((int)$id);
            foreach ($options as $index => $text) {
                $questionRepo->createOption((int)$id, $text, $index);
            }

            $db->commit();
            return $this->json(["status" => "success", "message" => "Question updated", "imageUrl" => $imageUrl]);
        } catch (\Exception $e) {
            if ($db->inTransaction()) $db->rollBack();
            return $this->json(["error" => $e->getMessage()], 500);
        }
    }

    public function uploadImage($file) {
        if (!isset($file['tmp_name']) || $file['error'] !== UPLOAD_ERR_OK) {
            return ["error" => "File upload failed"];
        }

        $tmpPath = $file['tmp_name'];
        $extension = pathinfo($file['name'], PATHINFO_EXTENSION);
        $newName = bin2hex(random_bytes(16)) . '.' . $extension;
        $destPath = __DIR__ . '/../../uploads/' . $newName;

        if (move_uploaded_file($tmpPath, $destPath)) {
            return ["status" => "success", "url" => "uploads/" . $newName];
        }

        return ["error" => "Could not move uploaded file"];
    }
}
