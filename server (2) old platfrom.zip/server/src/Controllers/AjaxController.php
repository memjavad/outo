<?php
namespace App\Controllers;

use App\Core\Database;
use App\Core\Validator;

class AjaxController extends BaseController {
    public function getAnalytics($data = null, $files = null, $adminId = null) {
        $db = Database::getInstance();
        
        $totalStudents = $db->query("SELECT COUNT(*) FROM students")->fetchColumn();
        $totalExams = $db->query("SELECT COUNT(*) FROM exams")->fetchColumn();
        $totalQuestions = $db->query("SELECT COUNT(*) FROM questions")->fetchColumn();
        $totalResults = $db->query("SELECT COUNT(*) FROM results")->fetchColumn();
        
        try {
            $stmt = $db->query("
                SELECT 
                    CASE 
                        WHEN score_percentage >= 90 THEN 'A'
                        WHEN score_percentage >= 80 THEN 'B'
                        WHEN score_percentage >= 70 THEN 'C'
                        WHEN score_percentage >= 60 THEN 'D'
                        ELSE 'F' 
                    END as grade,
                    COUNT(*) as count
                FROM results 
                GROUP BY grade
            ");
            $distribution = $stmt->fetchAll();
        } catch (\Exception $e) {
            $distribution = [];
        }

        return $this->json([
            'stats' => [
                'students' => $totalStudents,
                'exams' => $totalExams,
                'questions' => $totalQuestions,
                'results' => $totalResults
            ],
            'distribution' => $distribution
        ]);
    }

    public function deleteItem($data, $files = null, $adminId = null) {
        $validation = Validator::validate($data, [
            'type' => 'required|string',
            'id' => 'required|numeric'
        ]);

        if (!$validation['passes']) return $this->json(["error" => "Resource not found or invalid format"], 400);

        $db = Database::getInstance();
        $table = "";
        switch($validation['validated']['type']) {
            case 'student': $table = "students"; break;
            case 'question': $table = "questions"; break;
            case 'exam': $table = "exams"; break;
            case 'category': $table = "categories"; break;
            default: return $this->json(["error" => "Invalid type"], 400);
        }

        try {
            $stmt = $db->prepare("DELETE FROM $table WHERE id = ?");
            $stmt->execute([$validation['validated']['id']]);
            return $this->json(["status" => "success", "message" => "Item deleted"]);
        } catch (\Exception $e) {
            return $this->json(["error" => "Failed to delete: " . $e->getMessage()], 500);
        }
    }
}
