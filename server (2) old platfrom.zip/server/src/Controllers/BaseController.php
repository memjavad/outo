<?php
namespace App\Controllers;

class BaseController {
    protected function json($data, $code = 200) {
        http_response_code($code);
        header('Content-Type: application/json');
        echo json_encode($data);
        exit;
    }

    protected function getRequestBody() {
        return json_decode(file_get_contents("php://input"), true);
    }
}
