<?php
namespace App\Controllers;

use App\Core\Database;
use App\Core\Validator;
use App\Repositories\ResultRepository;
use App\Services\ResultService;

class ResultController extends BaseController {
    public function saveResult($data, $files = null, $adminId = null) {
        $validation = Validator::validate($data, ['studentName' => 'required|string']);
        if (!$validation['passes']) return $this->json(["error" => "studentName is required"], 400);

        $db = Database::getInstance();
        $resultService = new ResultService(new ResultRepository($db));

        try {
            return $this->json($resultService->saveResult($data));
        } catch (\Exception $e) {
            return $this->json(["error" => "Failed to save result: " . $e->getMessage()], 500);
        }
    }

    public function getStudentResults($data, $files = null, $studentId = null) {
        if (!$studentId) return $this->json(["error" => "Unauthorized"], 401);
        
        $db = Database::getInstance();
        $resultService = new ResultService(new ResultRepository($db));

        try {
            return $this->json($resultService->getStudentResults((int)$studentId));
        } catch (\Exception $e) {
            return $this->json(["error" => "Failed to fetch results: " . $e->getMessage()], 500);
        }
    }

    public function getLeaderboard($data, $files = null, $userId = null) {
        $validation = Validator::validate($data, ['exam_id' => 'required|numeric']);
        if (!$validation['passes']) return $this->json(["error" => "exam_id is required"], 400);

        $db = Database::getInstance();
        $resultService = new ResultService(new ResultRepository($db));

        try {
            return $this->json($resultService->getLeaderboard((int)$validation['validated']['exam_id']));
        } catch (\Exception $e) {
            return $this->json(["error" => "Failed to fetch leaderboard: " . $e->getMessage()], 500);
        }
    }

    public function clearResults($data, $files = null, $adminId = null) {
        $db = Database::getInstance();
        $resultService = new ResultService(new ResultRepository($db));

        try {
            return $this->json($resultService->clearResults());
        } catch (\Exception $e) {
            return $this->json(["error" => $e->getMessage()], 500);
        }
    }
}
