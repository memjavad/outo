<?php
namespace App\Controllers;

use App\Core\Database;
use PDO;

class SettingsController extends BaseController {
    public function getSettings($data, $files = null, $adminId = null) {
        $db = Database::getInstance();
        $settingsRepo = new \App\Repositories\SettingsRepository($db);
        $settings = $settingsRepo->getAll();
        
        // Security: Remove sensitive keys from public API
        unset($settings['tg_bot_token']);
        unset($settings['api_key']);
        
        return $this->json($settings);
    }

    public function updateSettings($data, $files = null, $adminId = null) {
        $db = Database::getInstance();
        $settingsRepo = new \App\Repositories\SettingsRepository($db);
        
        try {
            $settingsRepo->updateMany($data, ['api_key', 'action']);
            return $this->json(["status" => "success"]);
        } catch (\Exception $e) {
            return $this->json(["error" => $e->getMessage()], 500);
        }
    }

    public function fixDatabaseSchema($data, $files = null, $adminId = null) {
        $db = Database::getInstance();
        $migrator = new \App\Core\Migrator($db);
        $result = $migrator->up();
        
        if (isset($result['error']) || (isset($result['status']) && $result['status'] === 'error')) {
            return $this->json($result, 500);
        }
        
        return $this->json($result);
    }
}
