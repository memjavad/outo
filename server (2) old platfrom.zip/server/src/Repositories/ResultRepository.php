<?php
namespace App\Repositories;

use PDO;

class ResultRepository {
    private PDO $db;

    public function __construct(PDO $db) {
        $this->db = $db;
    }

    public function createResult(array $data): int {
        $stmt = $this->db->prepare("INSERT INTO results (student_name, student_id, exam_id, score_percentage, grade, total_questions, correct_answers, time_taken_seconds, gps_location, cheat_flag, answers_json) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->execute([
            $data['student_name'],
            $data['student_id'],
            $data['exam_id'],
            $data['score_percentage'],
            $data['grade'],
            $data['total_questions'],
            $data['correct_answers'],
            $data['time_taken_seconds'],
            $data['gps_location'],
            $data['cheat_flag'],
            $data['answers_json']
        ]);
        return (int)$this->db->lastInsertId();
    }

    public function markSessionCompleted(string $studentName) {
        $stmt = $this->db->prepare("UPDATE active_sessions SET status = 'completed' WHERE student_name = ? AND status = 'active'");
        $stmt->execute([$studentName]);
    }

    public function awardPoints(int $studentId, int $points) {
        $stmt = $this->db->prepare("UPDATE students SET points = points + ?, total_xp = total_xp + ? WHERE id = ?");
        $stmt->execute([$points, $points, $studentId]);
    }

    public function insertLedger(string $studentName, int $points, string $reason) {
        $stmt = $this->db->prepare("INSERT INTO points_ledger (student_name, amount, reason) VALUES (?, ?, ?)");
        $stmt->execute([$studentName, $points, $reason]);
    }

    public function getStudentResults(int $studentId): array {
        $stmt = $this->db->prepare("
            SELECT r.*, e.title as exam_title 
            FROM results r 
            LEFT JOIN exams e ON r.exam_id = e.id 
            WHERE r.student_id = ? 
            ORDER BY r.created_at DESC
        ");
        $stmt->execute([$studentId]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function getLeaderboard(int $examId): array {
        $stmt = $this->db->prepare("
            SELECT student_name, MAX(score_percentage) as score_percentage, MIN(time_taken_seconds) as time_taken_seconds 
            FROM results 
            WHERE exam_id = ? 
            GROUP BY student_name 
            ORDER BY score_percentage DESC, time_taken_seconds ASC 
            LIMIT 50
        ");
        $stmt->execute([$examId]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function clearResults() {
        $this->db->exec("DELETE FROM results");
    }

    public function isWebhookEnabled(): bool {
        $stmt = $this->db->query("SELECT setting_value FROM settings WHERE setting_key = 'webhook_enabled'");
        return $stmt->fetchColumn() === '1';
    }

    public function getActiveWebhooks(string $eventName): array {
        $stmt = $this->db->prepare("SELECT url FROM webhooks WHERE event_name = ? AND is_active = 1");
        $stmt->execute([$eventName]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}
