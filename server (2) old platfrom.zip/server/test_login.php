<?php
require_once __DIR__ . '/api.php';
// Not starting a real server, just require classes manually
