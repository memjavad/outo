<div id="essay_exams" class="tab-pane">
    <div class="grid" style="grid-template-columns: 400px 1fr; margin-bottom: 20px;">
        <div class="card">
            <h2 class="card-title"><i class="fas fa-plus-circle"></i> Create Essay Assignment</h2>
            <form id="add-essay-exam-form" class="add-exam-form-domain">
                <input type="hidden" name="exam_type" value="essay">
                <div class="form-group"><label>Assignment Title</label><input type="text" name="title" placeholder="e.g. Final Paper" required></div>
                <div class="form-group"><label>Description / Guidelines</label><textarea name="description" rows="5" placeholder="Write full instructions here..."></textarea></div>
                <button type="submit" class="btn btn-primary" style="width:100%;">Create Assignment</button>
            </form>
        </div>
        <div class="card">
            <h2 class="card-title"><i class="fas fa-book-open"></i> Assignments List</h2>
            <div class="table-container">
                <table class="table-compact">
                    <thead><tr><th>Title</th><th>Status</th><th>Actions</th></tr></thead>
                    <tbody id="essay-exam-list-body">
                        <?php foreach($essayExams as $ex): ?>
                        <tr id="exam-row-<?= $ex['id'] ?>">
                            <td style="font-weight:600;"><?= htmlspecialchars($ex['title']) ?></td>
                            <td>
                                <span class="badge" style="background:<?= $ex['is_active'] ? '#10B981' : '#6B7280' ?>; margin-bottom: 4px; display: inline-block;"><?= $ex['is_active'] ? 'Active' : 'Draft' ?></span><br>
                                <span class="badge" style="background:#8B5CF6; font-size: 0.65rem;">Essay</span>
                            </td>
                            <td>
                                <button class="btn btn-primary" style="padding:4px 8px; font-size:0.7rem;" onclick='showEditExam(<?= $ex["id"] ?>, <?= json_encode(json_encode($ex)) ?>)'><i class="fas fa-edit"></i></button>
                                <button class="btn btn-danger" style="padding:4px 8px; font-size:0.7rem;" onclick="deleteItem('exam', <?= $ex['id'] ?>)"><i class="fas fa-trash"></i></button>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
