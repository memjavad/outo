<div id="campaign_exams" class="tab-pane">
    <div class="grid" style="grid-template-columns: 400px 1fr; margin-bottom: 20px;">
        <div class="card">
            <h2 class="card-title"><i class="fas fa-plus-circle"></i> Create Story Campaign</h2>
            <form id="add-campaign-exam-form" class="add-exam-form-domain">
                <input type="hidden" name="exam_type" value="campaign">
                <div class="form-group"><label>Campaign Title</label><input type="text" name="title" placeholder="e.g. Chapter 1: Origins" required></div>
                <div class="form-group"><label>Description</label><textarea name="description" rows="3" placeholder="Story text..."></textarea></div>
                
                <div style="background:var(--surface-color); padding:10px; border-radius:8px; border:1px solid var(--border-color); margin-bottom:15px;">
                    <div class="form-group">
                        <label>Prerequisite Exam (Locks this campaign)</label>
                        <select name="prerequisite_exam_id">
                            <option value="">None (First Chapter)</option>
                            <?php foreach($exams as $ex): ?><option value="<?= $ex['id'] ?>"><?= htmlspecialchars($ex['title']) ?></option><?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Unlock Cost (Coins)</label>
                        <input type="number" name="unlock_cost" value="0" min="0">
                    </div>
                </div>

                <button type="submit" class="btn btn-primary" style="width:100%;">Create Campaign Chapter</button>
            </form>
        </div>
        <div class="card">
            <h2 class="card-title"><i class="fas fa-map"></i> Campaign Trajectory</h2>
            <div class="table-container">
                <table class="table-compact">
                    <thead><tr><th>Story Chapter</th><th>Requirements</th><th>Actions</th></tr></thead>
                    <tbody id="campaign-exam-list-body">
                        <?php foreach($campaignExams as $ex): ?>
                        <tr id="exam-row-<?= $ex['id'] ?>">
                            <td style="font-weight:600;">
                                <?= htmlspecialchars($ex['title']) ?>
                                <div style="font-size: 0.75rem; color: var(--text-muted);"><?= htmlspecialchars($ex['description'] ?? '') ?></div>
                            </td>
                            <td>
                                <?php if($ex['prerequisite_exam_id']): ?>
                                    <span class="badge" style="background:#F59E0B; font-size: 0.65rem;">Locked by ID: <?= $ex['prerequisite_exam_id'] ?></span>
                                <?php endif; ?>
                                <?php if($ex['unlock_cost'] > 0): ?>
                                    <span class="badge" style="background:#EAB308; font-size: 0.65rem; color:#000;">Cost: <?= $ex['unlock_cost'] ?> Coins</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <button class="btn btn-primary" style="padding:4px 8px; font-size:0.7rem;" onclick='showEditExam(<?= $ex["id"] ?>, <?= json_encode(json_encode($ex)) ?>)'><i class="fas fa-edit"></i></button>
                                <button class="btn btn-danger" style="padding:4px 8px; font-size:0.7rem;" onclick="deleteItem('exam', <?= $ex['id'] ?>)"><i class="fas fa-trash"></i></button>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Campaign Questions -->
    <div class="grid" style="grid-template-columns: 400px 1fr;">
        <div class="card">
            <h2 class="card-title"><i class="fas fa-file-signature"></i> Create Campaign Element</h2>
            <form id="add-campaign-question-form" class="add-question-form-domain">
                <input type="hidden" name="domain" value="campaign">
                <div class="form-grid" style="grid-template-columns: 1fr 1fr; gap: 15px;">
                    <div class="form-group">
                        <label>Category</label>
                        <select name="category_id">
                            <option value="">General</option>
                            <?php foreach($categories as $cat): ?><option value="<?= $cat['id'] ?>"><?= htmlspecialchars($cat['name']) ?></option><?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Link to Chapter</label>
                        <select name="exam_id" id="campaign-question-exam-select">
                            <option value="">None (Universal Campaign pool)</option>
                            <?php foreach($campaignExams as $ex): ?><option value="<?= $ex['id'] ?>"><?= htmlspecialchars($ex['title']) ?></option><?php endforeach; ?>
                        </select>
                    </div>
                </div>
                <div class="form-group"><label>Story Element (Question)</label><textarea name="question_text" rows="2" required></textarea></div>
                <div class="form-grid" style="grid-template-columns:1fr 1fr;">
                    <input type="text" name="option_0" placeholder="Option 1" required>
                    <input type="text" name="option_1" placeholder="Option 2" required>
                    <input type="text" name="option_2" placeholder="Option 3" required>
                    <input type="text" name="option_3" placeholder="Option 4" required>
                </div>
                <div class="form-group"><label>Correct Index</label><select name="correct_index"><option value="0">1</option><option value="1">2</option><option value="2">3</option><option value="3">4</option></select></div>
                <div class="form-group"><label>Image (Optional)</label><input type="file" name="question_image" accept="image/*"></div>
                <button type="submit" class="btn btn-primary" style="width:100%;">Add to Campaign Bank</button>
            </form>
        </div>
        <div class="card">
            <h2 class="card-title"><i class="fas fa-database"></i> Campaign Question Bank</h2>
            <div class="table-container">
                <table class="table-compact">
                    <thead><tr><th>Story Element</th><th>Actions</th></tr></thead>
                    <tbody id="campaign-question-list-body">
                        <?php foreach($campaignQuestions as $q): ?>
                        <tr id="question-row-<?= $q['id'] ?>">
                            <td>
                                <div style="font-weight:600;"><?= htmlspecialchars($q['question_text']) ?></div>
                                <?php if($q['image_url']): ?><img src="<?= htmlspecialchars($q['image_url']) ?>" style="height:35px; margin-top:5px; border-radius:4px;"><?php endif; ?>
                            </td>
                            <td>
                                <button class="btn btn-primary" style="padding:4px 8px; font-size:0.7rem;" onclick="showEditQuestion(<?= $q['id'] ?>)"><i class="fas fa-edit"></i></button>
                                <button class="btn btn-danger" style="padding:4px 8px; font-size:0.7rem;" onclick="deleteItem('question', <?= $q['id'] ?>)"><i class="fas fa-trash"></i></button>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
