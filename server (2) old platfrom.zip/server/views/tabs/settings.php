    <div id="settings" class="tab-pane">
        <form id="settings-form">
            <input type="hidden" name="csrf_token" value="<?= $csrfToken ?>">
            <div class="grid" style="grid-template-columns: repeat(auto-fit, minmax(350px, 1fr));">
                <!-- Section: Identity & Time -->
                <div class="card">
                    <h2 class="card-title"><i class="fas fa-palette"></i> Identity & Time</h2>
                    <div class="form-group">
                        <label>
                            App Title
                            <i class="fas fa-circle-question help-icon" data-tooltip="The name of the application displayed on students' mobile devices."></i>
                        </label>
                        <input type="text" name="app_title" value="<?= htmlspecialchars($appTitle) ?>">
                    </div>
                    <div class="form-group">
                        <label>
                            Primary Color
                            <i class="fas fa-circle-question help-icon" data-tooltip="The main theme color used for buttons and highlights in the Flutter app."></i>
                        </label>
                        <input type="color" name="primary_color" value="<?= htmlspecialchars($primaryColor) ?>" style="height:45px;">
                    </div>
                    <div class="form-group">
                        <label>
                            Flex Color Scheme
                            <i class="fas fa-circle-question help-icon" data-tooltip="The global premium app theme applied to all mobile devices dynamically."></i>
                        </label>
                        <select name="flex_color_scheme" class="form-control" style="width: 100%; padding: 10px; border-radius: 8px; border: 1px solid var(--border);">
                            <option value="blueWhale" <?= $flexColorScheme === 'blueWhale' ? 'selected' : '' ?>>Blue Whale</option>
                            <option value="indigo" <?= $flexColorScheme === 'indigo' ? 'selected' : '' ?>>Indigo Nights</option>
                            <option value="sakura" <?= $flexColorScheme === 'sakura' ? 'selected' : '' ?>>Japanese Sakura</option>
                            <option value="hippieBlue" <?= $flexColorScheme === 'hippieBlue' ? 'selected' : '' ?>>Hippie Blue</option>
                            <option value="brandBlue" <?= $flexColorScheme === 'brandBlue' ? 'selected' : '' ?>>Brand Blue</option>
                            <option value="money" <?= $flexColorScheme === 'money' ? 'selected' : '' ?>>Money Green</option>
                            <option value="ebonyClay" <?= $flexColorScheme === 'ebonyClay' ? 'selected' : '' ?>>Ebony Clay</option>
                            <option value="damask" <?= $flexColorScheme === 'damask' ? 'selected' : '' ?>>Damask Red</option>
                        </select>
                    </div>
                    <div class="form-grid" style="grid-template-columns:1fr 1fr;">
                        <div class="form-group">
                            <label>
                                Exam Timer (m)
                                <i class="fas fa-circle-question help-icon" data-tooltip="Total time limit (in minutes) for the entire exam session."></i>
                            </label>
                            <input type="number" name="exam_timer" value="<?= htmlspecialchars($examTimer) ?>">
                        </div>
                        <div class="form-group">
                            <label>
                                Question Timer (s)
                                <i class="fas fa-circle-question help-icon" data-tooltip="Optional time limit (in seconds) for each individual question. Set to 0 to disable."></i>
                            </label>
                            <input type="number" name="question_timer" value="<?= htmlspecialchars($questionTimer) ?>">
                        </div>
                    </div>
                </div>

                <!-- Section: Telegram Integration -->
                <div class="card">
                    <h2 class="card-title"><i class="fab fa-telegram"></i> Telegram Integration</h2>
                    <div class="form-group">
                        <label>
                            Telegram Bot Username
                            <i class="fas fa-circle-question help-icon" data-tooltip="The @username of your Telegram bot, used for the secure login flow."></i>
                        </label>
                        <input type="text" name="tg_bot_username" value="<?= htmlspecialchars($tgBotUsername) ?>" placeholder="e.g. MyQuizBot">
                    </div>
                    <div class="form-group">
                        <label>
                            Telegram Bot Token
                            <i class="fas fa-circle-question help-icon" data-tooltip="The API token provided by @BotFather for your Telegram bot."></i>
                        </label>
                        <input type="password" name="tg_bot_token" value="<?= htmlspecialchars($tgBotToken) ?>" placeholder="123456789:ABCDefgh...">
                        <small style="color:var(--text-muted); font-size:0.7rem;">Get this from <a href="https://t.me/BotFather" target="_blank">@BotFather</a></small>
                    </div>
                </div>

                <!-- Section: System Update -->
                <div class="card" id="update-card">
                    <h2 class="card-title"><i class="fas fa-cloud-arrow-up"></i> System Update</h2>
                    <p style="font-size:0.85rem; color:var(--text-muted); margin-bottom:15px;">
                        Current Version: <strong style="color:var(--primary-color);"><?= htmlspecialchars($systemVersion) ?></strong>
                    </p>
                    <div class="form-group">
                        <label>
                            Upload Update ZIP
                            <i class="fas fa-circle-question help-icon" data-tooltip="Upload a .zip file containing the new version of the dashboard and plugin files."></i>
                        </label>
                        <input type="file" id="update-zip-file" accept=".zip" style="width:100%; border:1px dashed var(--border-color); padding:10px; border-radius:8px;">
                    </div>
                    <div class="form-group">
                        <label>
                            New Version Number
                            <i class="fas fa-circle-question help-icon" data-tooltip="Enter the version number of the update (e.g., 1.4.0) to update the system footer."></i>
                        </label>
                        <input type="text" id="new-version-number" placeholder="e.g. 1.4.0">
                    </div>
                    <button type="button" class="btn btn-primary" onclick="performSystemUpdate()" style="width:100%;">Install Update</button>
                </div>

                <!-- Section: System Maintenance -->
                <div class="card">
                    <h2 class="card-title"><i class="fas fa-database"></i> System Maintenance</h2>
                    <p style="font-size: 0.85rem; color: var(--text-muted); margin-bottom: 15px;">
                        If you encounter SQL errors adding students or the platform behaves unexpectedly after an update, click this button to explicitly force a database schema upgrade.
                    </p>
                    <button type="button" class="btn btn-primary" onclick="fixDatabaseSchema()" style="width:100%;"><i class="fas fa-wrench"></i> Run Auto Database Update / Fix Schema</button>
                    <div id="db-fix-message" style="margin-top: 15px; font-size: 0.85rem; display: none;"></div>
                </div>
            </div>
            <div style="margin-top: 20px; text-align: right;">
                <button type="submit" class="btn btn-primary" style="padding: 12px 40px; font-weight: bold;"><i class="fas fa-save"></i> Save All Settings</button>
            </div>
        </form>
    </div>
