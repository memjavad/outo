<?php
// Get translation and language
$isRtl = ($lang == 'ar');
?>
<!DOCTYPE html>
<html lang="<?= $lang ?>" dir="<?= $isRtl ? 'rtl' : 'ltr' ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $t[$lang]['dashboard'] ?> | Premium Admin</title>
    <!-- Premium Fonts & Icons -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=Outfit:wght@400;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="style.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body class="<?= $isLoggedIn ? 'has-sidebar' : '' ?>">
    <?php if (!$isLoggedIn): ?>
        <!-- Login or Registration Screen (Styled) -->
        <div style="display: flex; align-items: center; justify-content: center; width: 100%; height: 100vh; background: var(--bg-color);">
            <div class="card" style="max-width: 400px; width: 90%; text-align: center;">
                <div class="logo" style="justify-content: center; margin-bottom: 30px;">
                    <div class="logo-icon"><i class="fas fa-shield-halved"></i></div>
                    <div class="logo-text">Auto Platform</div>
                </div>
                
                <?php if ($noAdmins): ?>
                    <h2 style="font-size: 1.2rem; font-weight: 800; color: var(--primary-color); margin-bottom: 10px;">Setup Admin Account</h2>
                    <p style="font-size: 0.85rem; color: var(--text-muted); margin-bottom: 25px;">No administrators found. Create the first one to begin.</p>
                <?php endif; ?>

                <?php 
                $errorMsg = isset($_SESSION['login_error']) ? $_SESSION['login_error'] : (isset($error) ? $error : null);
                if ($errorMsg): 
                    unset($_SESSION['login_error']);
                ?>
                    <div class="error" style="color: #E53E3E; background: #FFF5F5; padding: 12px; border-radius: 12px; margin-bottom: 20px; font-size: 0.9rem;">
                        <i class="fas fa-circle-exclamation"></i> <?= $errorMsg ?>
                    </div>
                <?php endif; ?>

                <form method="POST">
                    <input type="hidden" name="csrf_token" value="<?= $csrfToken ?>">
                    <div class="form-group" style="text-align: left;">
                        <label><?= $t[$lang]['username'] ?></label>
                        <input type="text" name="username" placeholder="Username" required>
                    </div>
                    <div class="form-group" style="text-align: left;">
                        <label><?= $t[$lang]['password'] ?></label>
                        <input type="password" name="password" placeholder="<?= $noAdmins ? 'Min. 6 characters' : '••••••••' ?>" required minlength="<?= $noAdmins ? '6' : '1' ?>">
                    </div>
                    
                    <?php if ($noAdmins): ?>
                        <button type="submit" name="register_admin" class="btn btn-primary" style="width: 100%; margin-top: 10px;">
                            Create & Login <i class="fas fa-user-plus"></i>
                        </button>
                    <?php else: ?>
                        <button type="submit" name="login" class="btn btn-primary" style="width: 100%; margin-top: 10px;">
                            <?= $t[$lang]['login_btn'] ?> <i class="fas fa-right-to-bracket"></i>
                        </button>
                    <?php endif; ?>

                    <div style="margin-top: 30px; font-size: 0.85rem; color: var(--text-muted);">
                        <a href="?lang=en" style="text-decoration: none; color: inherit;">EN</a> • 
                        <a href="?lang=ar" style="text-decoration: none; color: inherit;">العربية</a>
                    </div>
                </form>
            </div>
        </div>
    <?php elseif ($forcePasswordChange): ?>
        <!-- Force Password Change Screen -->
        <div style="display: flex; align-items: center; justify-content: center; width: 100%; height: 100vh; background: var(--bg-color);">
            <div class="card" style="max-width: 420px; width: 90%;">
                <div class="logo" style="justify-content: center; margin-bottom: 25px;">
                    <div class="logo-icon" style="background: linear-gradient(135deg, #f59e0b, #fbbf24);"><i class="fas fa-key"></i></div>
                    <div class="logo-text" style="color: #d97706;"><?= $t[$lang]['change_password'] ?></div>
                </div>
                <p style="text-align: center; color: var(--text-muted); margin-bottom: 25px; font-size: 0.9rem;">
                    For security reasons, please update your default password.
                </p>
                <form method="POST">
                    <input type="hidden" name="csrf_token" value="<?= $csrfToken ?>">
                    <div class="form-group">
                        <label><?= $t[$lang]['new_password'] ?></label>
                        <input type="password" name="new_password" placeholder="Min. 6 chars" minlength="6" required>
                    </div>
                    <div class="form-group">
                        <label><?= $t[$lang]['confirm_password'] ?></label>
                        <input type="password" name="confirm_password" placeholder="Confirm" minlength="6" required>
                    </div>
                    <button type="submit" name="change_password" class="btn btn-primary" style="width: 100%; margin-top: 10px;">
                        <i class="fas fa-save"></i> <?= $t[$lang]['change_password'] ?>
                    </button>
                </form>
            </div>
        </div>
    <?php else: ?>
        <!-- Sidebar Navigation -->
        <div class="sidebar">
            <div class="logo">
                <div class="logo-icon"><i class="fas fa-graduation-cap"></i></div>
                <div class="logo-text">Auto Platform</div>
            </div>
            
            <ul class="nav-links">
                <li class="nav-item">
                    <a href="#" class="nav-link active" data-tab="analytics">
                        <i class="fas fa-chart-pie"></i> <?= $t[$lang]['analytics'] ?>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="#" class="nav-link" data-tab="results">
                        <i class="fas fa-list-check"></i> <?= $t[$lang]['student_results'] ?>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="#" class="nav-link" data-tab="students">
                        <i class="fas fa-users-gear"></i> <?= $t[$lang]['manage_students'] ?>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="#" class="nav-link" data-tab="standard_exams">
                        <i class="fas fa-book-open"></i> Standard Exams
                    </a>
                </li>
                <li class="nav-item">
                    <a href="#" class="nav-link" data-tab="campaign_exams">
                        <i class="fas fa-map"></i> Campaign Mode
                    </a>
                </li>
                <li class="nav-item">
                    <a href="#" class="nav-link" data-tab="essay_exams">
                        <i class="fas fa-pen-nib"></i> Essay Manager
                    </a>
                </li>
                <li class="nav-item">
                    <a href="#" class="nav-link" data-tab="settings">
                        <i class="fas fa-gears"></i> <?= $t[$lang]['app_appearance'] ?>
                    </a>
                </li>
            </ul>

            <div style="margin-top: auto;">
                <div style="padding: 15px; background: rgba(99, 102, 241, 0.05); border-radius: 16px; margin-bottom: 20px; font-size: 0.8rem; color: var(--text-muted); border: 1px solid rgba(99, 102, 241, 0.1);">
                    <div style="font-weight: 700; color: var(--primary-color); margin-bottom: 6px;">Language / اللغة</div>
                    <a href="?lang=en" style="color: <?= $lang=='en' ? 'var(--primary-dark)' : 'inherit' ?>; font-weight: <?= $lang=='en' ? '700' : '400' ?>; text-decoration: none;">English</a> | 
                    <a href="?lang=ar" style="color: <?= $lang=='ar' ? 'var(--primary-dark)' : 'inherit' ?>; font-weight: <?= $lang=='ar' ? '700' : '400' ?>; text-decoration: none;">العربية</a>
                </div>
                <a href="?logout=1" class="btn btn-danger" style="width: 100%;">
                    <i class="fas fa-power-off"></i> <?= $t[$lang]['logout'] ?>
                </a>
            </div>
        </div>

        <!-- Main Content Area -->
        <main class="main-content">
            <header class="header">
                <div class="header-title">
                    <h1 id="page-title"><?= $t[$lang]['analytics'] ?></h1>
                    <p style="font-weight: 600; color: var(--text-muted);"><?= date('l, F j, Y') ?> · <span style="color: var(--primary-color);">Premium Admin Access</span></p>
                </div>
                <div style="display: flex; gap: 15px; align-items: center;">
                    <button class="btn btn-primary" onclick="window.location.reload()" style="padding: 10px 14px; border-radius: 8px;">
                        <i class="fas fa-arrows-rotate"></i>
                    </button>
                    <div style="width: 36px; height: 36px; border-radius: 10px; background: var(--primary-color); color: white; display: flex; align-items: center; justify-content: center; font-weight: 800; box-shadow: 0 4px 12px rgba(99, 102, 241, 0.2);">
                        <?= strtoupper(substr($_SESSION['admin_user'] ?? 'A', 0, 1)) ?>
                    </div>
                </div>
            </header>
    <?php endif; ?>
